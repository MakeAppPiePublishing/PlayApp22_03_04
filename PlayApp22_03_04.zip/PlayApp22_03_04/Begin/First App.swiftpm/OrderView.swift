//
//  OrderView.swift
//  OrderModelApp
//
//  Created by Steven Lipton on 7/30/22.
//

import SwiftUI

struct OrderView: View {
    @Binding var model:OrderModel
    @Binding var orderTotal:Double
    @Environment(\.horizontalSizeClass) var hSizeClass
    var  columns:[GridItem]{
        Array(
            repeating: GridItem(spacing:5),
            count: hSizeClass == .compact ? 5 : 10)
    }
    var body: some View {
            ScrollView{
                LazyVGrid(columns: columns){
                    ForEach(model.items){ item in
                        Image("\(item.item.id)_sm")
                            .resizable()
                            .scaledToFit()
                            .frame(maxHeight: hSizeClass == .compact ? 50 : 100)
                            .cornerRadius(10)
                            .onTapGesture {
                                model.remove(item:item)
                                orderTotal = model.total
                            }
                    }
                }
                .animation(.default,value:model.count)
            }
    }
}

 struct OrderView_Previews: PreviewProvider {
     static var previews: some View {
         OrderView(model:.constant(OrderModel(items: [OrderItem(item: testMenuItem, quantity: 1),OrderItem(item: testMenuItem,quantity: 2)])), orderTotal: .constant(10.00))
     }
 }

