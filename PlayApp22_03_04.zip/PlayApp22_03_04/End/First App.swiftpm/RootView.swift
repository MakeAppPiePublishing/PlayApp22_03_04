import SwiftUI

struct RootView: View {
    var menu:[MenuItem]
    @State var orders:OrderModel = OrderModel(items:[])
    @State var orderTotal:Double = 0 
    var body: some View {
        VStack {
            HeaderView(count: orders.count, total: orderTotal)
            OrderView(model: $orders, orderTotal: $orderTotal)
                .frame(maxHeight:150)
            MenuView(menu: menu, orders: $orders, orderTotal: $orderTotal)
        }
    }
}
